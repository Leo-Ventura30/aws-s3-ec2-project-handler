<?php
$accessKey = 'AKIAZO2THU7JDL76KPRC';
$secretKey = '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';
$region = 'us-east-2';
$bucket = 'osborn';
$arqName =  'logo.jpg';
$linkestatico = 'http://osborn.s3-website.us-east-2.amazonaws.com'
?>
