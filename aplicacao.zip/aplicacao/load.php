<!DOCTYPE html>
<html>
  <head>
    <title>AWS Cloud Practioner Essentials</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
  </head>

  <body style="background-color:black">
    <div class="container">

      <div class="row">
    		<div class="col-md-12">
      <?php include('menu.php'); ?>
      <div class="jumbotron" style="background-color:#555; color:#fff">

     <h1>
        Calma, segura a ansiendade!!!          
     </h1>
    <p>
        Na Parte 4 (quinta-feira) você vai ver a <b> Cereja do Bolo</b>.           
     </p>
    <p>
        Já clica no link abaixo e define o lembrete na Aula 4 para não perder.           
     </p>
          <a target="_blank" style="font-size:26px" href="https://youtu.be/nrp61t0l1S8"><b><u>ACESSAR AULA 4 NO YOUTUBE</u></b></a>
  </div>
</div>
</div>
</div>

<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/scripts.js"></script>
  </body>
</html>
